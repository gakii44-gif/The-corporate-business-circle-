#!/bin/bash
# Run inside your repo folder to remove unused files
git rm client_real.js client.combined.min.js fb_test.jpg pixieset_page.html highlights1.html
